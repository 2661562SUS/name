# YouAreAnIdiot
This is a recreation of Trojan.JS.YouAreAnIdiot origionally found on http://youareanidiot.org.
Every time you push a key the window will duplicate playing the flash animation of you are an idiot. 
This will continue untill Either, you run out of ram, you somehow manage to access task manager in time before your computer suffers, or you press the A key.  
TO CLOSE ALL WINDOWS: press the A key. 
I am not responciable for stress caused to your somputer, speakers, or your ears :)
