# YouAreAnIdiot with original javascript
Original YouAreAnIdiot javascript


I'm not responsible for the computer crashes. This is original youareandiot javascript :)

It might not work with newest Internet Explorer versions. Tested on IE 6 (Windows XP). Open idiot.html to start the youareanidiot.



Click that button to download: 

![Instructions](http://i.imgur.com/rWK11Nf.png)
